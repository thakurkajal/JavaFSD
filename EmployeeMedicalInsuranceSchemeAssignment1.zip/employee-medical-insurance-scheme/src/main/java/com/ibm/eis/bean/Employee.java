package com.ibm.eis.bean;

public class Employee {
	
	private int empId; 
	private String empName;
	private String empDesignation;
	private int empSalary;
	private String empInsuranceScheme;
	
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	public int getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}
	public String getEmpInsuranceScheme() {
		return empInsuranceScheme;
	}
	public void setEmpInsuranceScheme(String empInsuranceScheme) {
		this.empInsuranceScheme = empInsuranceScheme;
	}
	
	@Override
	public String toString() {
		return "Employee [name=" + empName + ", designation=" + empDesignation + ", salary=" + empSalary + ", empInsuranceScheme= " + empInsuranceScheme + "]";		
	}

}
