package com.ibm.kajal;

public class FirstClass {
	public void demoMethod() {
	System.out.println("Hello and Welcome...");
	System.out.println("In first class");
	}
}
