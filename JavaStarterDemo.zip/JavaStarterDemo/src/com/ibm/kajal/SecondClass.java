package com.ibm.kajal;

public class SecondClass {
	public static void main(String[] args) {
	FirstClass demo = new FirstClass();
	demo.demoMethod();
	System.out.println("In Second Class...");
	}

}
