package com.ibm.kajal.mavenstarter;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World! Welcome to Your First Maven Project..." );
    }
}
