package com.ibm.kajal;

import org.springframework.stereotype.Component;

@Component
public class Address {
	
	private String location;
	private int pincode;
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
}
