package com.ibm.kajal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class AnnotationEngineer implements Engineer{
	
	@Autowired		//using here we don't required constructor and setter method
	Address address;
	
	public Address getAddress() {
		return address;
	}
	

/**	public AnnotationEngineer(Address address) {
		super();
		this.address = address;
	}



	@Autowired    //by default it will work as a byType later byName
//	@Qualifier("secondAddress")		specify explicitly to autowire with secondAdress
	public void setAddress(Address address) {
		this.address = address;
	}

**/

	@Override
	public void workForWages() {
			System.out.println("The address of an annotation enginner is: " + getAddress().getLocation() + "," + getAddress().getPincode());
	}
	
}
