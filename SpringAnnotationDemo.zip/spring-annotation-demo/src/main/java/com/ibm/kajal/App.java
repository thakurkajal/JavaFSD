package com.ibm.kajal;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ibm.kajal.AnnotationEngineer;

public class App 
{
    public static void main( String[] args )
    {
    	try (//Load the XML File
    			ClassPathXmlApplicationContext theContext = new ClassPathXmlApplicationContext("applicationConfig.xml")) {
    				//Fetch the bean from container
    		AnnotationEngineer enginner = theContext.getBean("annotationEngineer", AnnotationEngineer.class);
    				
    				//call methods on the bean object
    				enginner.workForWages();
   		}
    }
}
