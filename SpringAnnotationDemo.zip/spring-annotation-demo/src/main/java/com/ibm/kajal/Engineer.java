package com.ibm.kajal;

public interface Engineer {
		void workForWages();
}
