package com.ibm.kajal.spring_starter;

public class SystemEngineer {
	
	private String location;

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
}
