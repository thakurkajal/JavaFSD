class Calculate{
	Calculate r;
	// void doSomething(int value){
	// 	if(value >= 0)
	// 		// Do something with that value here
	// 	else
	// 		// We should never have been here!
	// }
	//O

	void doSomething(int value){
		assert(value >= 0) : value; //Y
		assert(value == 0); // Y
		assert(value); //N
		assert(value) : "Some issues"; //N
		assert(value > 10) : System.out.println("Some issues..."); //N
		assert(value > 0) : new Calculate();//Y
		assert(value > 0) : Calculate ref; //N
		assert(value > 0) : r; //Y
		assert(value > 0) : Calculate.func(); //N
		assert(value > 0) : Calculate.met(value); //Y
			System.out.println("Move on and do that very thing...");
	}

	static void func(){
		System.out.println("Assertion turned wrong...");
	}

	static int met(value){
		return value;
	}



}

// Assertions - Java 4
// - are disabled by default
// - WHen our assertion is false, we get a STOP THE WORLD EXCEPTION : AssertionError


class AssertionsDemo{
	public static void main(String[] args) {
		new Calculate().doSomething(-987);
	}
}