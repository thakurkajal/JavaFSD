import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;
class BufferredReaderDemo{
	public static void main(String[] args) {
		try{
		BufferedReader reader = new BufferedReader(new FileReader(new File("mySecondFile.txt")));
		StringBuilder builder = new StringBuilder("");
		String dataFromFile;
		while((dataFromFile = reader.readLine()) != null){
			builder.append(dataFromFile);
		}
		// close the BufferedReader
		reader.close();

		System.out.println("Data from file is : " + builder);
	}catch(java.io.IOException io){
		System.out.println("Some issues : " + io.getMessage());
	}
	}
}