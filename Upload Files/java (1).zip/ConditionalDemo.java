class ConditionalDemo{
	public static void main(String[] args) {
		// int var = 901;

		boolean flag = false;

		if(flag)
			System.out.println("Yes");
		else
			System.out.println("No");
	}
}


a >=40, b>=40, c>=40 and sum >=125 -> Passing


12 1 2
WINTER
3 4 5 
SPRING
6 7 8
SUMMER
9 10 11
AUTUMN
