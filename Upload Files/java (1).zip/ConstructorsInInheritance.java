class A{
	A(boolean b){
		System.out.println("Inside A(boolean)..."); //1
	}
}
// java.lang.Object is the super class of every class in java



class B extends A{
	B(boolean flag){
		this();
		System.out.println("Inside B(boolean)..."); //3
	}
	B(){
		super(false);
		System.out.println("Inside B()...");//2
	}
	
}

class ConstructorsInInheritance{
	public static void main(String[] args) {
		B b = new B(false);
	}
}