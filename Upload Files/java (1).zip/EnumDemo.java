

	// Enumerations - Java 5.0

	// enum identifier{Const, Const, Const}

enum PizzaSize{SMALL(new int[]{34, 56, 88}), MEDIUM(new int[]{12, 4, 77}), LARGE(new int[]{12,9 });
	private int []size;
	PizzaSize(int []size){	
		this.size = size;
	}

	public int[] getSize(){
		return this.size;
	}
}

class PizzShop{
	void getMenu(){
		// PizzaSize size = PizzaSize.SMALL;
		// System.out.println(size);
		// size = PizzaSize.MEDIUM;
		// System.out.println(size);
		System.out.println("Dear Customer, we have the following sizes available for Pizza:");
		PizzaSize []values = PizzaSize.values();
		// for(int v = 0; v < values.length; v++){
		// 	System.out.println(values[v]);
		// }
		for(PizzaSize size : values){
			System.out.println("For Size : " + size);
			for(int value: size.getSize()){
				System.out.print(value + " ");
			}
			System.out.println("");

			// System.out.println(size + " serves " + size.getSize());
		}
	}
}

class EnumDemo{
	public static void main(String[] args) {
		new PizzShop().getMenu();
	}
}

	