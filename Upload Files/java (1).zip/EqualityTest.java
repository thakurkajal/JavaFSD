import java.util.HashSet;
class Footballer{
	private String name;
	private int code;

	Footballer(String name, int code){
		this.name = name;
		this.code = code;
	}

	public String getName(){
		return this.name;
	}

	public int getCode(){
		return this.code;
	}

	@Override
	public String toString(){
		return "Footballer [name: " + this.getName() + ", code: " + this.getCode() + "]";
	}


	@Override
	public int hashCode(){
		return 1;
	}



}

class EqualityTest{
	public static void main(String[] args) {
		HashSet set = new HashSet();

		set.add(new Footballer("Ronaldo", 567));
		set.add(new Footballer("Iniesta", 4));
		set.add(new Footballer("Gerrad", 889));

		set.add(new Footballer("Iniesta", 4));



		System.out.println("List of Footballers:");

		for (Object ref : set) {
			System.out.println(ref);
		}

	}
}






