import java.io.File;
class FileDirectoryWork{
	public static void main(String[] args) throws java.io.IOException {
		// Get a reference to the File object
		File dir = new File("newTestDir");//Just an object

		dir.mkdir();//This would create the new folder, if it doesn't exist already

		// Add files to this new folder now
		File theFile = new File(dir, "justAnotherFile.txt");
		theFile.createNewFile(); //Now create the file, if it doesn't exist already

		// Create and add another file to the same directory
		File anotherFile = new File(dir, "test.txt");
		anotherFile.createNewFile();

		// Try deleting a file within a directory
		// if(anotherFile.delete())
		// 	System.out.println("File deleted successfully...");
		// else
		// 	System.out.println("Issues while deleting the file...");

		// Try deleting the folder:testDir
		// if(dir.delete())
		// 	System.out.println("Directory testDir has been deleted...");
		// else
		// 	System.out.println("Some issues while deleting the directory testDir");


		//Try renaming a file
		// File newFile = new File(dir, "newNamed.txt");
		// theFile.renameTo(newFile);

		// Try to rename the directory
		File newDirectory = new File("newTestDir");
		dir.renameTo(newDirectory);


		// Code to traverse through the files of a folder
		File searchFiles = new File("newTestDir");
		String []filesWithinDir = searchFiles.list();
		for(String file: filesWithinDir){
			System.out.println(file);
		}

	}
}