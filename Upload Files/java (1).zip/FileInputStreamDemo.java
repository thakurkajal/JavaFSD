import java.io.File;
import java.io.FileInputStream;
class FileInputStreamDemo{
	public static void main(String[] args) {
		int data = 0;
		FileInputStream fis = null;
		File theFile = new File("mySecondFile.txt");
		if(!theFile.exists()){
			System.out.println("The file doesn't exist!");
			System.exit(0);
		}
		try{
		// Read from the file now
		fis = new FileInputStream(theFile);
	}catch(java.io.FileNotFoundException f){
		System.out.println("File not found : " + f.getMessage());
	}
		System.out.println("Contents of the file: ");
		try{
		while((data = fis.read()) != -1)
			System.out.print((char)data); 
	
		System.out.println("");
		fis.close();
	}catch(java.io.IOException i){
		System.out.println("Some issues while reading from file : " + i.getMessage());
	}
}
}