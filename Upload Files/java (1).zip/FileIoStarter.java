// File IO
// 	- File
// 	- FileWriter
// 	- FileReader
// 	- BufferedReader
// 	- BufferedWriter
// 	- PrintWriter
import java.io.File;
import java.io.IOException;
class FileIoStarter{
	public static void main(String[] args) throws IOException{
		// Create a new File
		File theFile = new File("myNewFile.txt");
		System.out.println(theFile.exists());//Should return false
		theFile.createNewFile();//It might create a new file
		System.out.println(theFile.exists());//Should return true
	}
}