// Using FileWriter and FileReader
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
// class FileWriterDemo{
// 	public static void main(String[] args) {
		

// 		try{
// 		File theFile = new File("mySecondFile.txt");//Just an object

// 		// Get a reference to the FileWriter object
// 		FileWriter writer = new FileWriter(theFile); //Create the file if it doesn't exist yet

// 		// Write some data to the file
// 		writer.write("Hello Guys\n We are storing data in files\n now");

// 		//Flush the writer before closing
// 		writer.flush();

// 		// Close the file
// 		writer.close();
// 	}catch(java.io.IOException io){
// 		System.out.println("Some issues writing to the file : " + io.getMessage());
// 	}

// 	}
// }

class FileReaderDemo{
	public static void main(String[] args) {
		FileReader theReader = null;
		// Get a reference to the FileReader object 
		try{
		 theReader = new FileReader(new File("mySecondFile.txt"));
		}catch(java.io.FileNotFoundException fe){
			System.out.println("File not found : " + fe.getMessage());
		}
		// Read data from the file
		 char []input = new char[45]; //Use this for storing the data
		 try{
		 System.out.println("Size of data read : " + theReader.read(input)); //Read the entire content from the file and put it in a char array

		 // Traverse through the char array
		 for(char data : input){
		 	System.out.println(data);
		 }

		 // Close the reader
		 theReader.close();
		}catch(java.io.IOException io){
			System.out.println("Some issues while reading : " + io.getMessage());
		}

	}
}