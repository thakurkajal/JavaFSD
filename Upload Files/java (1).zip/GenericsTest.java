class GenericsTest{
	public static void main(String[] args) {
		
		java.util.List<String> listOfNames = new java.util.ArrayList<String>();

		listOfNames.add("Rajiv");
		listOfNames.add("Reshma");
		listOfNames.add("Sana");
		listOfNames.add("Suhail");
		listOfNames.add("Kavitha");
	}
}