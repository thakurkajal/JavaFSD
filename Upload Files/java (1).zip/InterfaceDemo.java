// Interfaces
//	- We can only have abstract methods here(before java 8)
//	- We can't instantiate a interface 
//  - All of the abstract methods coming down from a interface
//  - need to be defined in the sub class or the sub class also
//  - needs to be declared as abstract
//  - All methods in an interface are abstract by default
//  - Only constants allowed in a interface
//  - All methods in a interface are implicitly public 

interface Human{
	int vr = 987; //public static final - by defualt
	void eat();
	void sleep();
	default void walk(){ //Only works post java 8.0
		System.out.println("Works after Java 8...");
	}
}

interface Employee{
	void workForWages();
	void sleep();
}

interface Fighter extends Human{
	void fightWell();
}

class Deepthi implements Fighter{
	@Override
	public void eat(){
		System.out.println("Sakshi's eat");
	}
	@Override
	public void sleep(){
		System.out.println("Sakshi's sleep");
	}
	@Override
	public void fightWell(){
		System.out.println("Deepthi is a real warrior :)");
	}
}

class Sakshi implements Human{
	@Override
	public void eat(){
		System.out.println("Sakshi's eat");
	}
	@Override
	public void sleep(){
		System.out.println("Sakshi's sleep");
	}
}



class Ramsha implements Human{ //No errors here
	void sing(){
		System.out.println("Ramsha sings well...");
	}
	@Override
	public void eat(){
		System.out.println("Ramsha's eat");
	}
	@Override
	public void sleep(){
		System.out.println("Ramsha's sleep");
	}
}

class Nivedha implements Human, Employee{ //Possible here
	@Override
	public void eat(){
		System.out.println("Nivedha's eat");
	}
	@Override
	public void sleep(){
		System.out.println("Nivedha's sleep");
	}
	@Override
	public void workForWages(){
		System.out.println("Nivedha works now...");
	}
}

class Bird{

}

class InterfaceDemo{
	public static void main(String[] args) {
		// Nivedha nivedha = new Nivedha();
		// nivedha.eat();
		// nivedha.sleep();
		// nivedha.workForWages();


		// Human ref = new Human(); Can't do that

		// Human ref = new Sakshi(); //Creating a reference variable of Human

		//Sakshi sakshi = neww Sakshi();

		// ref = sakshi; //IS-A

		// ref.eat(); //Sakshi's eat would be called
		// ref.sleep(); //Sakshi's sleep would be called

		//Ramsha ramsha = new Ramsha();

		// ref = new Ramsha(); //IS-A

		// ref.eat(); //Ramsha's eat would be called here
		// ref.sleep(); //Ramsha's sleep being called
		//ref.sing(); //Error here


		Human []refs = new Human[3]; //Works

		refs[0] = new Sakshi(); // IS- A -> Human

		refs[1] = new Ramsha(); // IS- A -> Human

		refs[2] = new Sakshi(); // IS-A -> Human

		for(Human ref : refs){
			ref.sleep();
			ref.eat();
			if(ref instanceof Ramsha)
				((Ramsha)ref).sing();
			}
		}












	}






// class A{
// 	private void func(){

// 	}
// }

// class B extends A{
// 	@Override
// 	void func(){

// 	}
// }


// Exceptional Scenario 1:
