import java.io.Console;
class Java6ConsoleDemo{
	public static void main(String[] args) {
		String userName;
		char []userPassword;

		// Get a reference to the Console
		Console theConsole = System.console();

		userPassword = theConsole.readPassword("%s", "Your Password : ");

		for(char pass : userPassword){
			theConsole.format("%c", pass);
		}
		System.out.println("");

		// Read the userName now
		userName = theConsole.readLine("%s", "Your UserName: ");

		theConsole.format("Output: %s \n", userName);
	}
}