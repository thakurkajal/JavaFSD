class LoopWork{
	public static void main(String[] args) {
		// for (int val = 50; val >= 38; val -= 2) {
		// 	System.out.println(val);
		// }

		// int val = 50;
		// while(val >= 38){
		// 	System.out.println(val);
		// 	val -=2;
		// }

		// int val = Integer.parseInt(args[0]), other;

		// while(val > 0){
		// 	other = val % 10;
		// 	val = val / 10;
		// 	System.out.print(other);
		// }



		// for(;val > 0;){
		// 	other = val % 10;
		// 	val = val / 10;
		// 	System.out.print(other);
		// }

		int val = 1;

		do{
			System.out.println(val);
			val++;
		}while(val > 100);



	}
}