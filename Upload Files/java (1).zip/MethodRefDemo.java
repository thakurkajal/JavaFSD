
// - Method References
// 	- 

class MethodRefDemo{
	public static void main(String[] args) {
		// Using Inner classes
		// Thread thread = new Thread(new Runnable(){
		// 	@Override
		// 	public void run(){
		// 		MethodRefDemo.displayMessage();
		// 		// System.out.println("Thread working...");
		// 	}
		// });
		// thread.start();

		//Or using Java 8 lambda expression:
	// new Thread(() -> System.out.println("Works?")).start();
	// new Thread(() -> MethodRefDemo.displayMessage()).start();

	// OR Using Method References with lambdas
	// new Thread(MethodRefDemo::displayMessage).start();

	//Calling non-static methods with Method Reference syntax
	new Thread(new MethodRefDemo()::displayMessage).start();

	}


	// static void displayMessage(){
	// 	System.out.println("We are moving ahead with lambdas...");
	// }

	void displayMessage(){
		System.out.println("We are moving ahead with lambdas...");
	}
}
