
class OurFirstProgramInJava{
	public static void main(String[] args) {
		System.out.println("Our First Program in Java, we are just getting started...");
		System.out.println("On the\rnext line...");
	}

}


// Camel Case
// 	MyFirst
// 	My


// 	addDetails()
// 	add()

// 	var
// 	varLength

// 	VAR
// 	SOME