
	// - Revisiting Overloading

class OverloadRevisit{
	public static void main(String[] args) {
		int b = 56;
		Some ref = new Some();
		ref.work(b);
	}
}


class Some{
	void work(Object b){
		System.out.println("work(Object)...");
	}
	void work(Long b){
		System.out.println("work(Long)");
	}

}

// int -> Integer ->IS-A(false) Long - too much for the jvm to do
// int -> Integer -> IS-A(true) Object


