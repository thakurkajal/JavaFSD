class PostJava5{
	public static void main(String[] args) {
// Polymorphic assignments don't work with Generics		
		// java.util.List<Object> listOfNames = new java.util.ArrayList<String>();
		java.util.List<String> listOfNames = new java.util.ArrayList();//Diamond syntax after Java 6



		listOfNames.add("Rajiv");
		listOfNames.add("Reshma");
		listOfNames.add("Sana");
		listOfNames.add("Suhail");
		listOfNames.add("Kavitha");
		// listOfNames.add(676); //Fails at compile time

		new PreJava5().doSomethingWithTheList(listOfNames);

		// for(String value : listOfNames){
		// 	System.out.println(value);
		// }

	}
}

// Imagine this class was written in the Pre-Generics World
class PreJava5{
	void doSomethingWithTheList(java.util.List list){
		for(int v = 0; v < list.size(); v++)
			System.out.println(list.get(v));

		// Changing the list
		list.add(456); //Surprisingly works
	}
}




	




