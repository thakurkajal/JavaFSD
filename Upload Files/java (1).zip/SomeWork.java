

	class SomeWork{
		public static void main(String[] args) {
			int var = new java.util.Scanner(System.in).nextInt();
			
			// System.out.println("Length of number entered is : " + var.length());// Error, can't use . with primitives

		}
	}