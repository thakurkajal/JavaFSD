class SomeWorkThread extends Thread{
public static void main(String[] args) throws InterruptedException {
	SomeWorkThread thread = new SomeWorkThread();
	thread.setName("sneha"); //We have named this thread to sneha
	thread.start(); //Indirectly calls run()
	thread.join(); // joins main to the end of the thread:main
	System.out.println(Thread.currentThread().getName() + " running...");//main running
}

@Override
public void run(){
	System.out.println(Thread.currentThread().getName() + " running...."); // sneha running
}


}


	// - join() : 