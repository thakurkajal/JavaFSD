import java.util.ArrayList;
import java.util.Collections;
class SortingCollections{
	public static void main(String[] args) {
		ArrayList<Footballer> listOfFootballers = new ArrayList<Footballer>();

		Footballer theFootballer = new Footballer("Gale", 14, "Wales");

		listOfFootballers.add(new Footballer("Angel Maria", 45, "Argentina"));
		listOfFootballers.add(new Footballer("Lionel Messi", 222, "Argentina"));
		listOfFootballers.add(new Footballer("Ronaldo", 21, "Portugal"));
		listOfFootballers.add(new Footballer("Ronaldo", 77, "Brazil"));
		listOfFootballers.add(new Footballer("Neymar", 21, "Brazil"));
		listOfFootballers.add(theFootballer);
		listOfFootballers.add(new Footballer("Saurez", 987, "Urugauy"));

		System.out.println("list before sorting : ");
		for(Footballer ref : listOfFootballers)
			System.out.println(ref.getName() + "\t");

		// Sort the list by code
		 // Collections.sort(listOfFootballers, new SortByCode());
		 // Collections.sort(listOfFootballers, new SortByName());
		
		 Collections.sort(listOfFootballers, (Footballer firstRef, Footballer secondRef) -> {
		 	return firstRef.getName().compareTo(secondRef.getName());
		 });

		 System.out.println("\nAfter sorting, list : ");

		 for(Footballer ref : listOfFootballers)
			System.out.print(ref.getName() + "\t");

		
	}
}


	// Comparable
	// 	- public int compareTo(Object obj)
	// 	{
	// 		//Define your custom sorting logic here
	// 	}

	// Comparator
	// 	- public int compare(Object ob1, Object ob2){

	// 	}





