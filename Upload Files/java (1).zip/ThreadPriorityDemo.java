
	// - Thread Priorities

	// 1-10




	// RUNNABLE -> sneha(3), sana(7), nikhil(8), deepthi(8)
	// RUNNING -> deepthi(8)


class ThreadPriorityDemo{
	public static void main(String[] args) {

		MyTask task = new MyTask();

		task.start();

		Thread firstThread = new Thread(task);
		Thread secondThread = new Thread(task);

		firstThread.setName("supriya");
		secondThread.setName("rishabh");

		// Set the Priorities
		firstThread.setPriority(7);
		secondThread.setPriority(9);

		firstThread.start();
		secondThread.start();

		System.out.println(Thread.currentThread());
	}
}

class MyTask implements Runnable{
	@Override
	public void run(){
		System.out.println(Thread.currentThread());
	}
}




	- yield()- 


