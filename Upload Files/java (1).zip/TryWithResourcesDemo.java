//try with resources > Java 7
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
class TryWithResourcesDemo{


	public static void main(String[] args) throws java.io.IOException {
		StringBuilder builder = null;


		try(
			BufferedReader reader = new BufferedReader(new FileReader("anotherFile.txt"))
			)
		{
		builder = new StringBuilder("");
		String dataFromFile;

		while((dataFromFile = reader.readLine()) != null){
			builder.append(dataFromFile);
		}
	}
		System.out.println("Data from file : " + builder);
	}
}
