// - Inter-Thread Communication
// 	- wait(), notify(), notifyAll()   - java.lang.Object
// 		- Can only be called from within a synchronized context

class WaitNotifyWork{
	public static void main(String[] args) throws InterruptedException {
		
		// ?

		synchronized(task){//main gets the lock on the object reffered to by task
		 System.out.println(Thread.currentThread().getName() + " about to go into waiting...");
		task.wait(6000); //puts main to wait, and releases the lock as well...
		 System.out.println(Thread.currentThread().getName() + " just woke up, resuming with the execution now...");
	}

		System.out.println("Sum of first 100 numbers is : " + task.total);
	}
}

