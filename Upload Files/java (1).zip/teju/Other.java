package teju;
import kajal.B;
class Other extends B{
	public static void main(String[] args) {
		// B ref = new B();

		Other ref = new Other();
		ref.func();
	}
}