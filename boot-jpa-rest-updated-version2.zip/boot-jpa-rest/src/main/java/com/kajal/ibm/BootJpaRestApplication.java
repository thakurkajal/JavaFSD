package com.kajal.ibm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootJpaRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootJpaRestApplication.class, args);
	}

}
