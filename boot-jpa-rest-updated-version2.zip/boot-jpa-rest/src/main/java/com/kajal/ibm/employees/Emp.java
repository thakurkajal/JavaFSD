package com.kajal.ibm.employees;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity //Tells JPA this is our Enitity Class
public class Emp {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private Integer empId;
	

	private String empName;
	

	private String empAddress;
	
//	@Transient
//	private String empProfile;
	
	public Emp() {
		
	}
	
	public Emp(Integer empId, String empName, String empAddress) {
		this.empId = empId;
		this.empName = empName;
		this.empAddress = empAddress;
	}

	public Integer getEmpId() {
		return empId;
	}


	public void setEmpId(Integer empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public String getEmpAddress() {
		return empAddress;
	}


	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}
	
	
	
}
