package com.kajal.ibm.employees;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	
	@Autowired
	EmployeeService service;

//	Return All Emp
	@RequestMapping("/employees")
	List<Emp> getAllEmployees(){
		return service.getAllEmployees();
	}
	
//	Get Employee by id
	@RequestMapping("/employees/{id}")
	Optional<Emp> getEmployeeById(@PathVariable int id){
		return service.getEmployeeById(id);
	}
	
//	Add a new Employee
	@PostMapping("/employees")
	void addNewEmployee(@RequestBody Emp theEmployee) {
		service.addNewEmployee(theEmployee);
	}
	
	
//	Update an already existing Employee
	@PutMapping("/employees/{id}")
	void updateEmployee(@RequestBody Emp theEmployee,@PathVariable int id) {
		service.updateEmployee(theEmployee, id);
	}
	
//	Delete an Employee
	@DeleteMapping("/employees/{id}")
	void deleteEmployee(@PathVariable int id) {
		service.deleteEmployee(id);
	}
	
	
//	Find Emp by Name(Fingers crossed)
	@RequestMapping("/employees/name/{empName}")
	List<Emp> getEmployeeByName(@PathVariable String empName){
		
		List<Emp> tempListOfEmployees = service.getEmployeeByName(empName);
		
		if(tempListOfEmployees.size() == 0)
			throw new EmployeeNotFoundException();
		return tempListOfEmployees;

	}
	
//	Find Emp by Address
	@RequestMapping("/employees/address/{empAddress}")
	List<Emp> getEmployeeByAddress(@PathVariable String empAddress){
		return service.getEmployeeByAddress(empAddress);
	}
	
	
	
	
	
}
