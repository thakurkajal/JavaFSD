package com.kajal.ibm.employees;

public class EmployeeNotFoundException extends RuntimeException {

}
