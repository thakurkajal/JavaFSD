package com.kajal.ibm.employees;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends CrudRepository<Emp, Integer> {

		List<Emp> findByEmpName(String empName);
		List<Emp> findByEmpAddress(String empAddress);
		
		
//		@Query(nativeQuery = true, value = "select * from employees where empAddress=(select address from locations)")
//		List<Emp> searchEmployees();
}
