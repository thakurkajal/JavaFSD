package com.kajal.ibm.employees;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

	@Autowired
	EmployeeRepository repo;
	
//	Fetch All Emp
	List<Emp> getAllEmployees(){
		return (List<Emp>) repo.findAll();
	}
	
//	Fetch Employee by id
	Optional<Emp> getEmployeeById(int id) {
		return repo.findById(id);
	}
	
//	Add a New Employee
	void addNewEmployee(Emp theEmployee) {
		repo.save(theEmployee);
	}
	
//	Update an already existing Employee
	void updateEmployee(Emp theEmployee, int id) {
		repo.save(theEmployee);
	}
	
//	Delete an Employee
	void deleteEmployee(int id) {
		repo.deleteById(id);
	}
	
//	Get an Employee by name
	List<Emp> getEmployeeByName(String empName){
		return repo.findByEmpName(empName);
	}
	
	
//	Get an Employee by address
	List<Emp> getEmployeeByAddress(String empAddress){
		return repo.findByEmpAddress(empAddress);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
