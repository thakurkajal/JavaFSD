package com.kajal.ibm.places;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.kajal.ibm.employees.Emp;

@Entity
public class Places {
		
	@Id
	private int placeId;
	private String placeName;
	private String placeState;
	
	@ManyToOne
	Emp emp;
	
	public Places() {
		
	}

	public Places(int placeId, String placeName, String placeState, Integer empId){
		this.placeId = placeId;
		this.placeName = placeName;
		this.placeState = placeState;
		
		this.emp = new Emp(empId, "", "");
	}

	public int getPlaceId() {
		return placeId;
	}

	public void setPlaceId(int placeId) {
		this.placeId = placeId;
	}

	public String getPlaceName() {
		return placeName;
	}

	public void setPlaceName(String placeName) {
		this.placeName = placeName;
	}

	public String getPlaceState() {
		return placeState;
	}

	public void setPlaceState(String placeState) {
		this.placeState = placeState;
	}

	public Emp getEmp() {
		return emp;
	}

	public void setEmp(Emp emp) {
		this.emp = emp;
	}	
}
