package com.kajal.ibm.places;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kajal.ibm.employees.Emp;

@RestController
@RequestMapping("/places")
public class PlacesController {
		@Autowired
		PlacesService service;
	
		//Get All the Places that belong to an Emp
		@RequestMapping("employees/{empId}/places")
		List<Places> getAllPlaces(@PathVariable int empId){
			return service.getAllPlaces(empId);
		}
		
		
		//Get Place By ID
		@RequestMapping("/{id}")
		Optional<Places> getPlaceById(@PathVariable Integer id){
			return service.getPlaceById(id);
		}
		
		
		//Add a New Place
		@RequestMapping(method=RequestMethod.POST, value="/employees/{empId}/places")
		void addPlaces(@RequestBody Places thePlace, @PathVariable Integer empId) {
			thePlace.setEmp(new Emp(empId, "", ""));
			service.addPlace(thePlace);
		}
		
		//Update a Place with a New Value
		@RequestMapping(method=RequestMethod.PUT, value="employees/{empId}/places/{placeId}")
		void updatePlaces(@RequestBody Places thePlace, @PathVariable Integer empId, @PathVariable Integer placeId) {
			thePlace.setEmp(new Emp(empId, "", ""));
			service.updatePlace(thePlace);
		}
		
		//Delete a Place
		@RequestMapping(method=RequestMethod.DELETE, value="employees/{empId}/places/{placeId}")
		void deletePlaces(@PathVariable Integer placeId) {
			service.deletePlace(placeId);
		}
}
