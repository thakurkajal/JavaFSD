package com.kajal.ibm.places;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface PlacesRepository extends CrudRepository<Places, Integer>{
		List<Places> findByEmpEmpId(Integer empId);
}
