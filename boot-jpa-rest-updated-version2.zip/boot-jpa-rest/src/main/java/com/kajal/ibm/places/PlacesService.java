package com.kajal.ibm.places;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PlacesService {
		@Autowired
		PlacesRepository repo;
		
		public List<Places> getAllPlaces(int empId){
			return repo.findByEmpEmpId(empId);
		}
		
		public Optional<Places> getPlaceById(Integer id){
			return repo.findById(id);
		}
		
		public void addPlace(Places thePlace) {
			repo.save(thePlace);
		}
		
		public void updatePlace(Places thePlace) {
			repo.save(thePlace);
		}
		
		public void deletePlace(Integer placeId) {
			repo.deleteById(placeId);
		}
}
